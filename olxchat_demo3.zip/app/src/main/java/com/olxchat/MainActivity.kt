package com.olxchat

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.util.Base64
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject

// ---------------------------------------------------------------
// Trial guard: 1 din (24 ghante) ka demo. Start time 2 jagah save hota hai:
// 1) app ke andar (SharedPreferences)
// 2) Downloads mein chhoti file (uninstall ke baad bhi reh sakti hai)
// Clock peeche karne par bhi demo khatam maana jata hai.
// ---------------------------------------------------------------
class TrialGuard(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("trial", Context.MODE_PRIVATE)
    private val fileName = "mp_demo_license.dat"
    private val trialMs = 24L * 60 * 60 * 1000

    private fun parse(t: String?): Pair<Long, Long>? {
        if (t == null) return null
        val p = t.trim().split(",")
        if (p.size != 2) return null
        val s = p[0].toLongOrNull()
        val l = p[1].toLongOrNull()
        return if (s != null && l != null && s > 0) Pair(s, l) else null
    }

    private fun readPrefs(): Pair<Long, Long>? {
        val s = prefs.getLong("s", 0L)
        val l = prefs.getLong("l", 0L)
        return if (s > 0) Pair(s, l) else null
    }

    private fun findMedia(): Uri? {
        if (Build.VERSION.SDK_INT < 29) return null
        return try {
            val base = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            ctx.contentResolver.query(
                base, arrayOf(MediaStore.MediaColumns._ID),
                MediaStore.MediaColumns.DISPLAY_NAME + "=?", arrayOf(fileName), null
            )?.use { c ->
                if (c.moveToFirst()) ContentUris.withAppendedId(base, c.getLong(0)) else null
            }
        } catch (e: Exception) { null }
    }

    private fun readMedia(): Pair<Long, Long>? {
        val uri = findMedia() ?: return null
        return try {
            val txt = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            parse(txt)
        } catch (e: Exception) { null }
    }

    private fun writeMedia(s: Long, l: Long) {
        if (Build.VERSION.SDK_INT < 29) return
        try {
            val res = ctx.contentResolver
            val data = (s.toString() + "," + l.toString()).toByteArray()
            val uri = findMedia()
            if (uri != null) {
                res.openOutputStream(uri, "wt")?.use { it.write(data) }
            } else {
                val cv = ContentValues()
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                val nu = res.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                if (nu != null) res.openOutputStream(nu)?.use { it.write(data) }
            }
        } catch (e: Exception) { }
    }

    private fun startTime(): Long {
        val a = readPrefs()
        val b = readMedia()
        return listOfNotNull(a?.first, b?.first).minOrNull() ?: System.currentTimeMillis()
    }

    /** true = demo chal sakta hai, false = khatam */
    fun check(): Boolean {
        val now = System.currentTimeMillis()
        val a = readPrefs()
        val b = readMedia()
        val start = listOfNotNull(a?.first, b?.first).minOrNull() ?: now
        val last = maxOf(a?.second ?: 0L, b?.second ?: 0L, start)
        val tampered = now < last - 10 * 60 * 1000
        val expired = tampered || (now - start) > trialMs || prefs.getBoolean("dead", false)
        if (expired) prefs.edit().putBoolean("dead", true).apply()
        val newLast = maxOf(now, last)
        prefs.edit().putLong("s", start).putLong("l", newLast).apply()
        writeMedia(start, newLast)
        return !expired
    }

    fun remainingMs(): Long {
        if (prefs.getBoolean("dead", false)) return 0L
        return startTime() + trialMs - System.currentTimeMillis()
    }
}

class MainActivity : AppCompatActivity() {
    private val PURPLE = Color.parseColor("#6A11CB")
    private val BLUE = Color.parseColor("#2575FC")
    private val PINK = Color.parseColor("#FF2D87")
    private val ORANGE = Color.parseColor("#FF8A00")
    private val GREEN = Color.parseColor("#12B76A")
    private val RED = Color.parseColor("#E5383B")
    private val PAGE_BG = Color.parseColor("#F5F3FF")
    private val DARK = Color.parseColor("#2B1B4D")
    private val desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private lateinit var guard: TrialGuard
    private lateinit var chip: TextView
    private lateinit var etStart: EditText
    private lateinit var etEnd: EditText
    private lateinit var tvRun: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var web: WebView
    private lateinit var loginWeb: WebView
    private lateinit var loginOverlay: LinearLayout
    private lateinit var expiredOverlay: LinearLayout
    private lateinit var runOverlay: LinearLayout
    private lateinit var runWebHolder: FrameLayout
    private lateinit var liveHolder: FrameLayout
    private lateinit var tvSent: TextView
    private lateinit var tvFail: TextView
    private lateinit var tvTotal: TextView
    private lateinit var tvNow: TextView
    private lateinit var runBar: ProgressBar
    private var nSent = 0
    private var nFail = 0
    private var nTotal = 0

    private var running = false
    private var imgData: String? = null
    private var loginLoaded = false
    private var pending: CompletableDeferred<String>? = null
    private var loaded: CompletableDeferred<Unit>? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val prefs by lazy { getSharedPreferences("olxdemo", MODE_PRIVATE) }

    inner class Bridge {
        @JavascriptInterface
        fun result(s: String) { pending?.complete(s) }

        @JavascriptInterface
        fun wasPicked(): Boolean = false
    }

    // ---------- helpers ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun solid(color: Int, radius: Int, stroke: Int? = null): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        if (stroke != null) g.setStroke(dp(1), stroke)
        return g
    }

    private fun grad(c1: Int, c2: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2))
        g.cornerRadius = dp(radius).toFloat()
        return g
    }

    private fun margins(v: View, l: Int, t: Int, r: Int, b: Int) {
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.setMargins(dp(l), dp(t), dp(r), dp(b))
        v.layoutParams = lp
    }

    private fun card(bgDrawable: GradientDrawable? = null): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = bgDrawable ?: solid(Color.WHITE, 16, Color.parseColor("#E4DEFA"))
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        margins(c, 14, 10, 14, 0)
        return c
    }

    private fun tv(t: String, size: Float = 14f, color: Int = DARK, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    private fun btn(t: String, c1: Int, c2: Int = c1, textColor: Int = Color.WHITE): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setTextColor(textColor)
        b.textSize = 14f
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.background = grad(c1, c2, 12)
        val lp = LinearLayout.LayoutParams(0, dp(50), 1f)
        lp.setMargins(dp(4), dp(6), dp(4), dp(6))
        b.layoutParams = lp
        return b
    }

    private fun fullBtn(b: Button): Button {
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, dp(50))
        lp.setMargins(0, dp(6), 0, dp(4))
        b.layoutParams = lp
        return b
    }

    private fun edit(hintText: String, lines: Int = 1): EditText {
        val e = EditText(this)
        e.hint = hintText
        e.minLines = lines
        e.textSize = 13f
        e.gravity = Gravity.TOP or Gravity.START
        e.background = solid(PAGE_BG, 10, Color.parseColor("#D9D0F7"))
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.setMargins(0, dp(6), 0, dp(6))
        e.layoutParams = lp
        return e
    }

    private fun setupWeb(w: WebView) {
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.useWideViewPort = true
        w.settings.loadWithOverviewMode = true
        w.settings.builtInZoomControls = true
        w.settings.displayZoomControls = false
        w.settings.userAgentString = desktopUa
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
    }

    // ---------- buy / contact ----------
    private fun openWhatsApp() {
        try {
            val u = Uri.parse(WA_URL + "?text=" + Uri.encode("Marketing Pro software buy karna hai"))
            startActivity(Intent(Intent.ACTION_VIEW, u))
        } catch (e: Exception) {
            Toast.makeText(this, "Number: " + PHONE, Toast.LENGTH_LONG).show()
        }
    }

    private fun callNow() {
        try {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + PHONE)))
        } catch (e: Exception) {
            Toast.makeText(this, "Number: " + PHONE, Toast.LENGTH_LONG).show()
        }
    }

    private fun buyDialog(reason: String) {
        if (isFinishing) return
        try {
            AlertDialog.Builder(this)
                .setTitle("\uD83D\uDD12 Full Version Feature")
                .setMessage(reason + "\n\nBuy karne ke liye rabta karein:\n\uD83D\uDCDE " + PHONE)
                .setPositiveButton("\uD83D\uDED2 Buy Now") { _, _ -> openWhatsApp() }
                .setNeutralButton("\uD83D\uDCDE Call") { _, _ -> callNow() }
                .setNegativeButton("Baad mein", null)
                .show()
        } catch (e: Exception) { }
    }

    private fun showExpired() {
        expiredOverlay.visibility = View.VISIBLE
    }

    private fun updateChip() {
        val ms = guard.remainingMs()
        if (ms <= 0) {
            chip.text = "\u23F0 Demo khatam"
        } else {
            val h = ms / 3600000
            val m = (ms % 3600000) / 60000
            chip.text = "\u23F3 " + h + " ghante " + m + " min baqi"
        }
    }

    // ---------- UI ----------
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        guard = TrialGuard(this)
        try {
            assets.open("promo.jpg").use { ins ->
                imgData = "data:image/jpeg;base64," + Base64.encodeToString(ins.readBytes(), Base64.NO_WRAP)
            }
        } catch (e: Exception) { }

        // Header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.background = grad(PURPLE, BLUE, 0)
        header.setPadding(dp(18), dp(30), dp(18), dp(18))
        header.addView(tv("Marketing Pro", 26f, Color.WHITE, true))
        header.addView(tv("DEMO VERSION", 12f, Color.parseColor("#FFD9EC"), true))
        chip = tv("", 12f, Color.WHITE, true)
        chip.setPadding(dp(12), dp(5), dp(12), dp(5))
        chip.background = solid(Color.parseColor("#33FFFFFF"), 14)
        val chipLp = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT)
        chipLp.setMargins(0, dp(10), 0, 0)
        header.addView(chip, chipLp)

        // Buy banner
        val buy = card(grad(ORANGE, PINK, 16))
        buy.addView(tv("\uD83C\uDF81 Poora version kharidein", 17f, Color.WHITE, true))
        buy.addView(tv("Apna message, picture, tez speed aur sab options", 12f, Color.parseColor("#FFF1E0")))
        val phoneTv = tv("\uD83D\uDCDE " + PHONE, 22f, Color.WHITE, true)
        phoneTv.setPadding(0, dp(8), 0, dp(4))
        buy.addView(phoneTv)
        val bBuy = btn("\uD83D\uDED2 Buy Now", Color.WHITE, Color.WHITE, PINK)
        val bCall = btn("\uD83D\uDCDE Call", Color.WHITE, Color.WHITE, ORANGE)
        val buyRow = LinearLayout(this)
        buyRow.addView(bBuy)
        buyRow.addView(bCall)
        buy.addView(buyRow)

        // Step 1: login
        val s1 = card()
        s1.addView(tv("1   Login", 16f, PURPLE, true))
        s1.addView(tv("OLX account se ek baar login karein.", 12f, Color.GRAY))
        val bLogin = btn("\uD83D\uDD11 OLX par Login karein", BLUE, PURPLE)
        s1.addView(fullBtn(bLogin))

        // Step 2: categories (fixed) + page range
        val s2 = card()
        s2.addView(tv("2   Categories", 16f, PURPLE, true))
        s2.addView(tv("Demo mein in categories par jayega:", 12f, Color.GRAY))
        val linksBox = tv(DEMO_LINK_NAMES, 13f, DARK)
        linksBox.background = solid(Color.parseColor("#EFEAFE"), 10, Color.parseColor("#D9D0F7"))
        linksBox.setPadding(dp(12), dp(10), dp(12), dp(10))
        val llp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        llp.setMargins(0, dp(6), 0, dp(6))
        linksBox.layoutParams = llp
        s2.addView(linksBox)
        val bLinks = btn("\u2795 Apne links lagayein \uD83D\uDD12", PINK, ORANGE)
        s2.addView(fullBtn(bLinks))
        etStart = edit("Start page")
        etEnd = edit("End page")
        etStart.inputType = 2
        etEnd.inputType = 2
        etStart.setText(prefs.getString("sp", "1"))
        etEnd.setText(prefs.getString("ep", "3"))
        val pr = LinearLayout(this)
        val ps = LinearLayout(this); ps.orientation = LinearLayout.VERTICAL
        ps.addView(tv("Page se", 11f, Color.GRAY)); ps.addView(etStart)
        val pe = LinearLayout(this); pe.orientation = LinearLayout.VERTICAL
        pe.addView(tv("Page tak", 11f, Color.GRAY)); pe.addView(etEnd)
        ps.layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(0, 0, dp(6), 0) }
        pe.layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        pr.addView(ps); pr.addView(pe)
        s2.addView(pr)

        // Step 3: locked message + picture
        val s3 = card()
        s3.addView(tv("3   Message", 16f, PURPLE, true))
        s3.addView(tv("\uD83D\uDD12 Demo mein sirf yeh message aur yeh picture jayegi:", 12f, Color.GRAY))
        val msgBox = tv(DEMO_MSG, 13f, DARK)
        msgBox.background = solid(Color.parseColor("#EFEAFE"), 10, Color.parseColor("#D9D0F7"))
        msgBox.setPadding(dp(12), dp(10), dp(12), dp(10))
        val mlp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        mlp.setMargins(0, dp(6), 0, dp(6))
        msgBox.layoutParams = mlp
        s3.addView(msgBox)
        val preview = ImageView(this)
        preview.adjustViewBounds = true
        preview.maxHeight = dp(200)
        try {
            assets.open("promo.jpg").use { ins ->
                val o = BitmapFactory.Options()
                o.inSampleSize = 2
                preview.setImageBitmap(BitmapFactory.decodeStream(ins, null, o))
            }
        } catch (e: Exception) { }
        s3.addView(preview, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        val bEdit = btn("\u270F\uFE0F Apna message \uD83D\uDD12", PINK, ORANGE)
        val bPic = btn("\uD83D\uDDBC Picture upload \uD83D\uDD12", PURPLE, PINK)
        val lockRow = LinearLayout(this)
        lockRow.addView(bEdit)
        lockRow.addView(bPic)
        s3.addView(lockRow)

        // Run controls
        val runCard = card()
        val bStart = btn("\u25B6  START", GREEN, Color.parseColor("#0E9F5A"))
        val bStop = btn("\u23F9  STOP", RED, Color.parseColor("#B5179E"))
        val runRow = LinearLayout(this)
        runRow.addView(bStart)
        runRow.addView(bStop)
        runCard.addView(runRow)
        spinner = ProgressBar(this)
        spinner.isIndeterminate = true
        spinner.visibility = View.GONE
        tvRun = tv("Taiyar", 14f, DARK, true)
        tvRun.gravity = Gravity.CENTER
        runCard.addView(spinner, LinearLayout.LayoutParams(MATCH_PARENT, dp(36)))
        runCard.addView(tvRun, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // Live view
        val live = card()
        live.addView(tv("Live view", 13f, PURPLE, true))
        web = WebView(this)
        setupWeb(web)
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) { loaded?.complete(Unit) }
        }
        liveHolder = FrameLayout(this)
        liveHolder.addView(web, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        live.addView(liveHolder, LinearLayout.LayoutParams(MATCH_PARENT, dp(230)))

        val bBattery = btn("\uD83D\uDD0B Background ke liye Battery allow", DARK, DARK)
        val batWrap = LinearLayout(this)
        batWrap.setPadding(dp(10), dp(8), dp(10), dp(24))
        batWrap.addView(fullBtn(bBattery), LinearLayout.LayoutParams(MATCH_PARENT, dp(46)))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(header, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        col.addView(buy); col.addView(s1); col.addView(s2); col.addView(s3)
        col.addView(runCard); col.addView(live); col.addView(batWrap)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(PAGE_BG)
        scroll.addView(col)

        // Login overlay
        loginWeb = WebView(this)
        setupWeb(loginWeb)
        loginOverlay = LinearLayout(this)
        loginOverlay.orientation = LinearLayout.VERTICAL
        loginOverlay.setBackgroundColor(Color.WHITE)
        loginOverlay.visibility = View.GONE
        val lTop = LinearLayout(this)
        lTop.setBackgroundColor(PURPLE)
        lTop.gravity = Gravity.CENTER_VERTICAL
        val bBack = tv("\u2190  Wapas", 16f, Color.WHITE, true)
        bBack.setPadding(dp(16), dp(16), dp(16), dp(16))
        lTop.addView(bBack)
        loginOverlay.addView(lTop, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        val lHint = tv("OLX par login karein, phir Wapas dabayein.", 12f, Color.DKGRAY)
        lHint.setPadding(dp(14), dp(8), dp(14), dp(8))
        loginOverlay.addView(lHint)
        loginOverlay.addView(loginWeb, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        // Expired overlay
        expiredOverlay = LinearLayout(this)
        expiredOverlay.orientation = LinearLayout.VERTICAL
        expiredOverlay.gravity = Gravity.CENTER
        expiredOverlay.background = grad(PINK, PURPLE, 0)
        expiredOverlay.setPadding(dp(28), dp(28), dp(28), dp(28))
        expiredOverlay.visibility = View.GONE
        expiredOverlay.isClickable = true
        val e1 = tv("\u23F0 Demo khatam ho gaya", 24f, Color.WHITE, true)
        e1.gravity = Gravity.CENTER
        val e2 = tv("Poora version lene ke liye abhi rabta karein", 14f, Color.parseColor("#FFE3F1"))
        e2.gravity = Gravity.CENTER
        e2.setPadding(0, dp(10), 0, dp(10))
        val e3 = tv("\uD83D\uDCDE " + PHONE, 28f, Color.WHITE, true)
        e3.gravity = Gravity.CENTER
        e3.setPadding(0, dp(10), 0, dp(20))
        val eBuy = btn("\uD83D\uDED2 Buy Now (WhatsApp)", Color.WHITE, Color.WHITE, PINK)
        val eCall = btn("\uD83D\uDCDE Call karein", ORANGE, ORANGE)
        expiredOverlay.addView(e1, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        expiredOverlay.addView(e2, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        expiredOverlay.addView(e3, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        expiredOverlay.addView(fullBtn(eBuy))
        expiredOverlay.addView(fullBtn(eCall))

        // Full-screen run overlay (live view + status)
        runOverlay = LinearLayout(this)
        runOverlay.orientation = LinearLayout.VERTICAL
        runOverlay.setBackgroundColor(Color.BLACK)
        runOverlay.visibility = View.GONE
        runOverlay.isClickable = true
        val rTop = LinearLayout(this)
        rTop.orientation = LinearLayout.VERTICAL
        rTop.background = grad(PURPLE, BLUE, 0)
        rTop.setPadding(dp(14), dp(26), dp(14), dp(10))
        val rRow = LinearLayout(this)
        tvSent = tv("", 15f, Color.WHITE, true)
        tvFail = tv("", 15f, Color.WHITE, true)
        tvTotal = tv("", 15f, Color.WHITE, true)
        for (t in listOf(tvSent, tvFail, tvTotal)) {
            t.gravity = Gravity.CENTER
            rRow.addView(t, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        rTop.addView(rRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        runBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        runBar.max = 1
        runBar.progress = 0
        val barLp = LinearLayout.LayoutParams(MATCH_PARENT, dp(10))
        barLp.setMargins(0, dp(8), 0, dp(4))
        rTop.addView(runBar, barLp)
        tvNow = tv("", 12f, Color.parseColor("#E9E3FF"))
        tvNow.gravity = Gravity.CENTER
        rTop.addView(tvNow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        runOverlay.addView(rTop, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        runWebHolder = FrameLayout(this)
        runOverlay.addView(runWebHolder, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        val rStop = btn("\u23F9  STOP", RED, Color.parseColor("#B5179E"))
        val rBot = LinearLayout(this)
        rBot.setBackgroundColor(Color.WHITE)
        rBot.setPadding(dp(10), dp(4), dp(10), dp(4))
        rBot.addView(rStop)
        runOverlay.addView(rBot, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        rStop.setOnClickListener { doStop() }
        updateStats()

        val frame = FrameLayout(this)
        frame.addView(scroll, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        frame.addView(loginOverlay, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        frame.addView(runOverlay, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        frame.addView(expiredOverlay, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(frame)

        // Actions
        bBuy.setOnClickListener { openWhatsApp() }
        bCall.setOnClickListener { callNow() }
        eBuy.setOnClickListener { openWhatsApp() }
        eCall.setOnClickListener { callNow() }
        msgBox.setOnClickListener { buyDialog("Apna message likhna sirf full version mein milta hai.") }
        bEdit.setOnClickListener { buyDialog("Apna message likhna sirf full version mein milta hai.") }
        bPic.setOnClickListener { buyDialog("Picture upload karke bhejna sirf full version mein milta hai.") }
        bLogin.setOnClickListener {
            if (!guard.check()) { showExpired(); return@setOnClickListener }
            loginOverlay.visibility = View.VISIBLE
            if (!loginLoaded) { loginLoaded = true; loginWeb.loadUrl("https://www.olx.com.pk") }
        }
        bLinks.setOnClickListener { buyDialog("Apne category links lagana sirf full version mein milta hai.") }
        bBack.setOnClickListener { closeLogin() }
        bStart.setOnClickListener { doStart() }
        bStop.setOnClickListener { doStop() }
        bBattery.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + packageName)))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        web.loadUrl("https://www.olx.com.pk")
        if (!guard.check()) showExpired()
        updateChip()
    }

    private fun closeLogin() {
        CookieManager.getInstance().flush()
        loginOverlay.visibility = View.GONE
    }

    override fun onResume() {
        super.onResume()
        if (!guard.check()) showExpired()
        updateChip()
    }

    override fun onPause() {
        super.onPause()
        prefs.edit().putString("sp", etStart.text.toString())
            .putString("ep", etEnd.text.toString()).apply()
        CookieManager.getInstance().flush()
        if (running) web.resumeTimers()
    }

    override fun onStop() {
        super.onStop()
        if (running) web.resumeTimers()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (loginOverlay.visibility == View.VISIBLE) closeLogin()
        else moveTaskToBack(true)
    }

    // ---------- run ----------
    private suspend fun navigate(url: String) {
        loaded = CompletableDeferred()
        web.loadUrl(url)
        withTimeoutOrNull(20000) { loaded!!.await() }
        delay(500)
    }

    private fun updateStats() {
        tvSent.text = "\u2705 Gaye: " + nSent
        tvFail.text = "\u274C Fail: " + nFail
        tvTotal.text = "\uD83D\uDCCB Total: " + nTotal
        runBar.max = if (nTotal < 1) 1 else nTotal
        runBar.progress = nSent + nFail
    }

    private fun showRun() {
        (web.parent as? ViewGroup)?.removeView(web)
        runWebHolder.addView(web, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        runOverlay.visibility = View.VISIBLE
    }

    private fun hideRun() {
        (web.parent as? ViewGroup)?.removeView(web)
        liveHolder.addView(web, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        runOverlay.visibility = View.GONE
    }

    private suspend fun runJs(script: String, timeout: Long): String {
        pending = CompletableDeferred()
        web.evaluateJavascript(script, null)
        return withTimeoutOrNull(timeout) { pending!!.await() } ?: ""
    }

    private fun parseUrls(raw: String): List<String> {
        return try {
            val a = JSONArray(raw)
            val out = ArrayList<String>()
            for (i in 0 until a.length()) out.add(a.getString(i))
            out
        } catch (ex: Exception) {
            emptyList()
        }
    }

    private fun doStop() {
        if (!running) return
        running = false
        pending?.complete("")
        loaded?.complete(Unit)
        tvRun.text = "Ruk raha hai..."
    }

    private fun doStart() {
        if (running) return
        if (!guard.check()) { showExpired(); return }
        val cats = DEMO_LINKS.toList()
        val sp = etStart.text.toString().toIntOrNull() ?: 1
        val ep = etEnd.text.toString().toIntOrNull() ?: 1
        if (sp < 1 || sp > ep) { Toast.makeText(this, "Page range theek karein", Toast.LENGTH_LONG).show(); return }

        running = true
        nSent = 0; nFail = 0; nTotal = 0
        updateStats()
        tvNow.text = "Shuru ho raha hai..."
        tvRun.text = "Chal raha hai..."
        spinner.visibility = View.VISIBLE
        showRun()
        ContextCompat.startForegroundService(this, Intent(this, KeepAliveService::class.java))
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mpdemo:run")
            wakeLock?.acquire(6 * 60 * 60 * 1000L)
        } catch (e: Exception) { }

        lifecycleScope.launch {
            try {
                val sent = prefs.getStringSet("sent", emptySet())!!.toMutableSet()
                outer@ for (cat in cats) {
                    val base = cat.substringBefore("?")
                    for (page in sp..ep) {
                        if (!running) break@outer
                        tvNow.text = "\uD83D\uDD0D Ads dhoond raha hai (page " + page + ")..."
                        navigate(base + "?page=" + page)
                        var urls = parseUrls(runJs(LINKS_JS.replace("__SPD__", SPD), 20000))
                        if (urls.isEmpty()) {
                            delay(1500)
                            urls = parseUrls(runJs(LINKS_JS.replace("__SPD__", SPD), 20000))
                        }
                        val todo = urls.filter { it !in sent }
                        nTotal += todo.size
                        updateStats()
                        for (u in todo) {
                            if (!running) break@outer
                            if (!guard.check()) { running = false; showExpired(); break@outer }
                            if (prefs.getInt("dsent", 0) >= DEMO_MAX) {
                                running = false
                                buyDialog("Demo ki limit (" + DEMO_MAX + " messages) poori ho gayi.")
                                break@outer
                            }
                            tvNow.text = "\uD83D\uDCE4 " + (nSent + nFail + 1) + " / " + nTotal + " ko message + picture ja raha hai..."
                            navigate(u)
                            val img = imgData
                            val raw = runJs(CHAT_JS.replace("__MSG__", JSONObject.quote(DEMO_MSG)).replace("__IMG__", if (img != null) JSONObject.quote(img) else "null"), 60000)
                            val status = try { JSONObject(raw).getString("status") } catch (e: Exception) { "" }
                            if (status.contains("Sent")) {
                                sent.add(u)
                                nSent++
                                prefs.edit().putStringSet("sent", sent).putInt("dsent", prefs.getInt("dsent", 0) + 1).apply()
                            } else if (status.contains("Not Logged In")) {
                                running = false
                                Toast.makeText(this@MainActivity, "Pehle Step 1 mein Login karein", Toast.LENGTH_LONG).show()
                                break@outer
                            } else {
                                nFail++
                            }
                            updateStats()
                            tvRun.text = "\u2705 " + nSent + " gaye  |  \u274C " + nFail + " fail"
                            delay(300 + (Math.random() * 400).toLong())
                        }
                    }
                }
            } finally {
                running = false
                stopService(Intent(this@MainActivity, KeepAliveService::class.java))
                try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (e: Exception) { }
                spinner.visibility = View.GONE
                hideRun()
                tvRun.text = "\u2705 Mukammal: " + nSent + " gaye, " + nFail + " fail (total " + nTotal + ")"
            }
        }
    }

    companion object {
        const val PHONE = "03012562502"
        const val WA_URL = "https://wa.me/923012562502"
        const val DEMO_MSG = "Apne product ki marketing ke liye marketing software chahiye? Rabta karein: 03012562502"
        const val DEMO_MAX = 50
        const val SPD = "0.5"
        val DEMO_LINKS = arrayOf(
            "https://www.olx.com.pk/islamabad_g4060615/services_c619",
            "https://www.olx.com.pk/property-for-sale_c2",
            "https://www.olx.com.pk/cars_c84",
            "https://www.olx.com.pk/houses_c1721"
        )
        const val DEMO_LINK_NAMES = "\u2022 Islamabad - Services\n\u2022 Property for Sale\n\u2022 Cars\n\u2022 Houses"

        const val LINKS_JS = """
(async function(){
  const K=__SPD__;
  const wait=ms=>new Promise(r=>setTimeout(r,Math.round(ms*K)));
  const sel='a[href*="/item/"]';
  for(let i=0;i<40&&!document.querySelector(sel);i++){await new Promise(r=>setTimeout(r,150));}
  for(let i=0;i<3;i++){window.scrollBy(0,1500);await wait(800);}
  const urls=[];
  document.querySelectorAll(sel).forEach(a=>{
    const h=a.getAttribute('href'); if(!h) return;
    let f=h.startsWith('http')?h:'https://www.olx.com.pk'+h;
    f=f.split('?')[0]; if(!urls.includes(f)) urls.push(f);
  });
  Android.result(JSON.stringify(urls));
})();
"""
        const val CHAT_JS = """
(async function(){
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const until=async(fn,max)=>{
    const t0=Date.now();
    while(Date.now()-t0<max){
      let v=null; try{v=fn();}catch(e){}
      if(v) return v;
      await sleep(100);
    }
    return null;
  };
  let status='Chat Failed';
  const IMG=__IMG__;
  const ATT='M537.07 92.46';
  function done(){Android.result(JSON.stringify({status:status}));}
  function findSend(){
    const c=Array.from(document.querySelectorAll('button,[role="button"],[data-aut-id*="send"]'));
    for(const el of c){
      if(el.innerHTML&&el.innerHTML.includes(ATT)) continue;
      const t=((el.innerText||'')+' '+(el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')+' '+(el.getAttribute('data-aut-id')||'')).toLowerCase();
      if(t.includes('send')) return el;
    }
    return null;
  }
  function findChat(){
    return Array.from(document.querySelectorAll('button, a, span')).find(b=>{
      const t=(b.innerText||'').toLowerCase().trim();
      const a=(b.getAttribute('aria-label')||'').toLowerCase().trim();
      return t.includes('chat')||a.includes('chat');
    })||null;
  }
  function findInput(){
    return document.querySelector('textarea')||
      document.querySelector('input[placeholder*="message" i]')||
      document.querySelector('input[placeholder*="Write" i]')||
      document.querySelector('div[contenteditable="true"]')||
      document.querySelector('div[role="textbox"]');
  }
  try{
    const chatBtn=await until(findChat,5000);
    if(!chatBtn){status='Chat Hidden';done();return;}
    chatBtn.click();
    const input=await until(findInput,6000);
    if(!input){status='Field Blocked / Not Logged In';done();return;}
    input.focus(); input.click(); await sleep(150);
    const msg=__MSG__;
    if(input.isContentEditable){input.textContent=msg; input.dispatchEvent(new Event('input',{bubbles:true}));}
    else{
      const proto=input.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto,'value').set.call(input,msg);
      input.dispatchEvent(new Event('input',{bubbles:true}));
      input.dispatchEvent(new Event('change',{bubbles:true}));
    }
    await sleep(300);
    const sendBtn=await until(findSend,1500);
    if(sendBtn){sendBtn.click(); status='Message Sent';}
    else{
      const o={key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true};
      input.dispatchEvent(new KeyboardEvent('keydown',o));
      input.dispatchEvent(new KeyboardEvent('keypress',o));
      input.dispatchEvent(new KeyboardEvent('keyup',o));
      status='Sent (Enter)';
    }
    await sleep(900);

    if(IMG){
      let handled=false;
      const origClick=HTMLInputElement.prototype.click;
      const origPicker=HTMLInputElement.prototype.showPicker;
      let cap=null;
      try{
        const mime=IMG.substring(5,IMG.indexOf(';'));
        const bin=atob(IMG.split(',')[1]);
        const bytes=new Uint8Array(bin.length);
        for(let i=0;i<bin.length;i++) bytes[i]=bin.charCodeAt(i);
        const file=new File([bytes],'photo.jpg',{type:mime||'image/jpeg'});
        const applyTo=(inp)=>{
          const dt=new DataTransfer(); dt.items.add(file); inp.files=dt.files;
          inp.dispatchEvent(new Event('input',{bubbles:true}));
          inp.dispatchEvent(new Event('change',{bubbles:true}));
          handled=true;
        };
        HTMLInputElement.prototype.click=function(){
          if(this.type==='file'){applyTo(this);return;}
          return origClick.apply(this,arguments);
        };
        if(origPicker){
          HTMLInputElement.prototype.showPicker=function(){
            if(this.type==='file'){applyTo(this);return;}
            return origPicker.apply(this,arguments);
          };
        }
        cap=(e)=>{
          const t=e.target; let inp=t.closest&&t.closest('input[type="file"]');
          if(!inp&&t.closest){const lb=t.closest('label'); if(lb&&lb.control&&lb.control.type==='file') inp=lb.control;}
          if(inp){e.preventDefault(); applyTo(inp);}
        };
        document.addEventListener('click',cap,true);
        const findPath=(r)=>Array.from(r.querySelectorAll('path')).find(p=>(p.getAttribute('d')||'').startsWith(ATT))||null;
        let icon=null; let scope=input;
        for(let i=0;i<8&&scope&&!icon;i++){scope=scope.parentElement; if(scope) icon=findPath(scope);}
        if(!icon) icon=findPath(document);
        let target=null;
        if(icon) target=icon.closest('button,[role="button"],label,a')||icon.closest('svg').parentElement;
        if(!target){
          target=Array.from(document.querySelectorAll('button,[role="button"],label,[data-aut-id]')).find(el=>{
            const t=((el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')+' '+(el.getAttribute('data-aut-id')||'')).toLowerCase();
            return /attach|upload|photo|image|clip/.test(t);
          })||null;
        }
        if(target){target.click(); await until(()=>handled,3000);}
        if(!handled){const fi=document.querySelector('input[type="file"]'); if(fi){applyTo(fi);} await sleep(300);}
        if(handled){
          await sleep(1200);
          const b2=await until(findSend,2500);
          if(b2) b2.click();
          await sleep(1000);
          status+=' + Pic';
        }
      }catch(e){}
      finally{
        HTMLInputElement.prototype.click=origClick;
        if(origPicker) HTMLInputElement.prototype.showPicker=origPicker;
        if(cap) document.removeEventListener('click',cap,true);
      }
    }
  }catch(e){status='Error';}
  done();
})();
"""
    }
}
